<META HTTP-EQUIV="Refresh" CONTENT="5; url=http://adm.int.datafull.com/repl/repl.php">
<TITLE>DF REPL Status</TITLE>
<?php

/*######################################################################
# repl.php v1.1
#
# A poor man's file replication service web reporting utility
# Depends on sinquiar.php
#
# 2004 JPV
######################################################################*/

$inipath="/home/adm.int.datafull.com/sinquiar.ini";

$inifile=parse_ini_file($inipath, TRUE); // get sites settings to an array
// look on sinquiar.php for more comments

$statusdir=$inifile[Settings][webbasedir].$inifile[Settings][statusdir];

$alertvalue=$inifile[Settings][alertvalue];

foreach($inifile as $section => $values)
// wohoo, we have a $values array with individual site settings
// on each pass of the loop (with n passes as n sections of the
// $inifile array)
// each section is enclosed with brackets on the ini file ($section var)
// there is one special section: "Settings" which holds the
// global settings

{
  if ($section != "Settings")
   {
     $sites[$section]=$values;  
   }

}

$now=date("d/m/Y  H:i:s.");

echo("<h2>DATAFULL.COM Websites<br>Estado de la replicacion al ".$now."</h2><hr>");

foreach($sites as $section => $site)
// look on sinquiar.php for more comments
{
  $last_started=filemtime($statusdir.$section." started.stat");
  $last_ended=filemtime($statusdir.$section." ended.stat");
 
  $date_started=date("d/m/Y  H:i:s.", $last_started);
  $date_ended=date("d/m/Y  H:i:s.", $last_ended);

  if($last_started > $last_ended)
  {
    echo("<h3>".$section."</h3>Descripcion: ".$site[description]."<br>");
    echo("Status: <FONT COLOR=red><b>PROCESANDO ARCHIVOS</b></FONT><br>");
    echo("Ultima replicacion terminada el: ".$date_ended."<br>");
    echo("Replicacion en proceso comenzada el: ".$date_started."<br>");
    echo("<a target=\"_blank\" href=\"".$section.".txt\">Ver replicacion actual</a><br>");
    $nowtime=time();
    $solong = $nowtime - $last_started;
    $diff = $nowtime - $last_ended;
    echo("Este sitio en particular lleva ".$solong." segundos en proceso de replicacion<br>");
    echo("La copia en produccion lleva alrededor de<b> ".$diff." segundos desactualizada.</b><br>");
  }
  else
  {
    echo("<h3>".$section."</h3>Descripcion: ".$site[description]."<br>");    
    echo("Status: <b>Esperando turno</b><br>");
    echo("Ultima replicacion comenzada el: ".$date_started."<br>");
    echo("Ultima replicacion terminada el: ".$date_ended."<br>");
    echo("<a target=\"_blank\" href=\"".$section.".txt\">Ver ultima replicacion</a><br>");
    $nowtime=time();
    $lasted = $last_ended - $last_started;
    $diff = $nowtime - $last_ended;
    echo("Este sitio en particular tardo ".$lasted." segundos en replicarse la ultima vez<br>");
    echo("La copia en produccion lleva alrededor de<b> ".$diff." segundos desactualizada.</b><br>");
  }

  if (time() - $last_ended > $alertvalue && $inifile[Settings][active] == "1")
  {
    echo("<FONT COLOR=red><b>ATENCION: <br>");
    echo("\tLa replicacion de este sitio se esta demorando demasiado.<br>");
    echo("\tEs probable que haya errores de copia, o se este procesando un archivo de gran tama�o.<br>");
    echo("\tPor favor chequee el informe del progreso de la replicacion.</b></FONT>");
  }
  echo("<hr>");

}

if ($inifile[Settings][active] != "1")
{
   echo("La replicacion ha sido suspendida por el administrador del sistema "); 
   echo("de manera deliberada");
}
else
{
   echo("Si no hay ningun sitio marcado <b>EN PROCESO</b>, en un maximo de un minuto ");
   echo("el proceso de copia deberia comenzar nuevamente");
}

echo("<hr>");
echo("Powered by TorabaThreads Technology");

?>

