#!/usr/local/bin/php -q
<?php

/*######################################################################
# sinquiar.php v1.12 with TorabaThreads technology
#
# A poor man's file replication service
# Depends on cron, rsync, php4-cli, and a good flock() implementation
# Be aware that flock() does not work on NFS filesystems
#
# 2004 JPV & Associates.
# TorabaThreads is a Patented Technology - Licensed from WireTied Corp.
######################################################################*/

// Configuration values

$inipath="/home/www/home/adm.int.datafull.com/sinquiar.ini";

$inifile=parse_ini_file($inipath, TRUE); // get sites settings to an array
// Now we have a $inifile array, with n elements
// n is the number of sections of our ini file, and the number of sites
// Every element of this asociative array is another array, holding the 
// site configuration


// Program

if ($inifile[Settings][active] != 1)
{
   exit();  // Replication has been deactivated by the administrator
}


foreach($inifile as $section => $values)
// wohoo, we have a $values array with individual site settings
// on each pass of the loop (with n passes as n sections of the
// $inifile array) 
// each section is enclosed with brackets on the ini file ($section var)
// there is one special section: "Settings" which holds the 
// global settings

{
  if ($section=="Settings")
   {
       $settings=$values; // now we have a special array for global settings
   }
  else
   {
     // last registered ended time per section (if exists).
     //	 needed to establish a priority order
     $filestat=$settings[basedir].$settings[statusdir].$section." ended.stat";
     if (file_exists($filestat))
        {
           $sectiontime = filemtime($filestat);
	}
     else
	{
           
           $sectiontime = (double)microtime()*1000000;  // if the file doesnt exist 
                                                        // fake different consecutive keys 	
	}	
     
     // This preserves the site name as an element (and is essential to report 
     // status, because our .stat files use this to reference a site). 
     // Formerly $section was always the array key, and the name of the files was 
     // easier to form. Yes, it's somewhat ugly, but this way is easier to sort
     $values[name]=$section;

     // We build our $sites array with a timestamp as key, to order properly
     // First we have to eliminate possible duplicated keys (another side-effect
     // of this shameless hack
     if (is_array($sites))
     {  	
        if (array_key_exists($sectiontime, $sites)) 
        {
          // if the key exists, we append a fake floating point part
          $sectiontime = $sectiontime .".".(double)microtime()*1000000;
        }
     }
     $sites[$sectiontime]=$values;     	

   }							

}

ksort($sites, SORT_NUMERIC); // Older sites go on top, so they are replicated first

$begintime=time(); // start time to control loop

foreach($sites as $section => $site)
{
	
  $lockfile="/tmp/".$site[name].".lock";
  $fp = fopen($lockfile, "w+");

  if (flock($fp, LOCK_EX | LOCK_NB)) // acquire a per-site, exclusive, non-blocking lock
  { // Everything that goes from here is locked, until lock release

    if ($site[delete] == 1)
    {
	$rsdelete=" --delete";
    }
    else
    {
	$rsdelete="";
    }
        
    // this is all about, we form the system() line over here
    $options = "--exclude-from=".$settings[basedir].$site[patternfile];
    $options.= $rsdelete." --recursive --owner --group --times --temp-dir=/tmp";
    $options.= " --password-file ".$settings[rspassdir].$site[passfile];
    $options.= " --max-delete=20 --compress --timeout=180 ".$site[addflags];
    $from = "rsync://".$site[username]."@".$site[rsserver].$site[remotefolder];
    $to = $site[localfolder];
    // send stdout and stderr go to a file
    $output = "> \"".$settings[basedir]."htdocs/repl/".$site[name].".txt\" 2>&1";	

    $line=$settings[rsyncpath]." ".$options." ".$from." ".$to." ".$output;
    $filestat=$settings[basedir].$settings[statusdir].$site[name];

    copy($filestat." started.stat", $filestat." started.stat.bak"); // backup previous status

    touch($filestat." started.stat");	
    echo($line); // Uncomment only for debbugging purposes
    echo("\n");  
    unset($execstat);
    system($line, $execstat); // witness the SYS Powa!.
    
    //sleep(1);  // fake delay - for debug purposes

    if($execstat == "0")
    {   // rsync success, commit	
        //echo $execstat."\n";	
    	touch($filestat." ended.stat");
        unlink($filestat." started.stat.bak");
    }
    else 
    {   // rsync error, rollback
        //echo $execstat; 
        copy($filestat." started.stat.bak", $filestat." started.stat");
        unlink($filestat." started.stat.bak");
    }	

    flock($fp, LOCK_UN); // release the lock, we are done!
  }
  else
  {
    // Error: The lock could not be acquired
    // Nothing goes to stdout here, crontab execution needs to be quiet.
    // The non-blocking lock makes the program to exit right away
    // avoiding to pile up rsync executions.
  }

  // This is what makes TorabaThreads tick... 
  // Superduper control loop limit to avoid croning to death
  if (time() - $begintime > $settings[cloop]) 
	{
	 exit();
	}

  fclose($fp);
}

?>
